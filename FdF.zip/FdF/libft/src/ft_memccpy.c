/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gsferopo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/06/09 16:35:46 by gsferopo          #+#    #+#             */
/*   Updated: 2017/06/09 16:35:48 by gsferopo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void		*ft_memccpy(void *dst, const void *src, int c, size_t n)
{
	int		i;
	char	*cdst;
	char	*csrc;

	cdst = dst;
	csrc = (char *)src;
	i = -1;
	n++;
	if (ft_strlen(csrc) > 0)
	{
		while (--n != 0 && csrc[++i] != '\0')
		{
			cdst[i] = csrc[i];
			if (csrc[i] == c)
				return (&dst[i + 1]);
		}
		n++;
		while (--n != 0)
			cdst[i++] = '\0';
	}
	return (NULL);
}
