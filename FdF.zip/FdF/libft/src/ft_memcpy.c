/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gsferopo <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/06/09 17:01:51 by gsferopo          #+#    #+#             */
/*   Updated: 2017/06/09 17:01:58 by gsferopo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void		*ft_memcpy(void *dst, const void *src, size_t n)
{
	int		i;
	char	*cdst;
	char	*csrc;

	cdst = dst;
	csrc = (char *)src;
	i = -1;
	n++;
	if (ft_strlen(csrc) > 0)
	{
		while (--n > 0 && csrc[++i] != '\0')
			cdst[i] = csrc[i];
		n++;
		while (--n > 0)
			cdst[i++] = '\0';
	}
	else
		while (--n > 0)
			cdst[i++] = '\0';
	dst = (void *)cdst;
	return (dst);
}
